//
// Created by jeff on 23-6-17.
//

#include "shared.h"
#include <iostream>

int main() {
    return shared( 10);
}