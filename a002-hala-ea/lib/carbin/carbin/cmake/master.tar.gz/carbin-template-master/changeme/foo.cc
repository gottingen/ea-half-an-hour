//
// Created by ubuntu on 23-5-29.
//

int foo(int a) {
    return  a +1;
}