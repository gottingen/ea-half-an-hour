# carbin-template

carbin template is a cmake template that help project easy to build and build package 
for conda.

it can be add to project by carbin

```shell
carbin create --name project_name --test --examples --benchmark --requirements
```

